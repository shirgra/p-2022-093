#!/bin/sh
# Step 1: Create *.json and *.p4info
#> /dev/null
make 
echo "From build_dependencies/makestart.sh: Created .json and .p4info files."